import React from "react";
import { type CheckboxGroupProps } from "@wix/headless-forms/react";
import {
  Field,
  FieldLabel,
  FieldInput,
  FieldInputWrapper,
  FieldError,
} from "../../ui/forms/Form";

const CheckboxGroup = ({
  id,
  value,
  label,
  description,
  required,
  readOnly,
  options,
  numberOfColumns = 1,
  customOption,
  minItems,
  maxItems,
  onChange,
  onBlur,
  onFocus,
  // @ts-expect-error
  errorMessage,
}: CheckboxGroupProps) => {
  const currentValues = value || [];

  const handleCheckboxChange = (optionValue: string) => {
    const isSelected = currentValues.includes(optionValue);
    let newValues: string[];

    if (isSelected) {
      newValues = currentValues.filter((v) => v !== optionValue);
    } else {
      newValues = [...currentValues, optionValue];
    }

    onChange(newValues);
    onBlur();
  };

  return (
    <Field id={id}>
      <FieldLabel>
        <label className="text-foreground font-paragraph mb-3">
          {label}
          {required && <span className="text-destructive ml-1">*</span>}
        </label>
      </FieldLabel>
      <FieldInputWrapper>
        <FieldInput>
          <div className="space-y-2">
            {options.map((option) => {
              const isSelected = currentValues.includes(option.value);
              return (
                <label
                  key={option.id}
                  className="flex items-center gap-3 cursor-pointer text-foreground font-paragraph"
                >
                  <input
                    type="checkbox"
                    checked={isSelected}
                    disabled={readOnly}
                    onChange={() => handleCheckboxChange(option.value)}
                    onFocus={onFocus}
                    className="w-4 h-4 text-primary bg-background border-foreground/20 rounded focus:ring-2 focus:ring-primary/50 disabled:opacity-50 disabled:cursor-not-allowed"
                    aria-invalid={!!(required && currentValues.length === 0)}
                    aria-required={required}
                  />
                  {option.label}
                </label>
              );
            })}
          </div>
        </FieldInput>
        <FieldError className="text-destructive text-sm font-paragraph">
          {errorMessage}
        </FieldError>
      </FieldInputWrapper>
    </Field>
  );
};

export default CheckboxGroup;
