import React from "react";
import { type TagsProps } from "@wix/headless-forms/react";
import {
  Field,
  FieldLabel,
  FieldInput,
  FieldInputWrapper,
  FieldError,
} from "../../ui/forms/Form";

const Tags = ({
  id,
  value,
  label,
  showLabel,
  options,
  onChange,
  onBlur,
  onFocus,
  // @ts-expect-error
  errorMessage,
}: TagsProps) => {
  const currentValues = value || [];

  const handleTagToggle = (optionValue: string) => {
    const isSelected = currentValues.includes(optionValue);
    let newValues: string[];

    if (isSelected) {
      newValues = currentValues.filter((v) => v !== optionValue);
    } else {
      newValues = [...currentValues, optionValue];
    }

    onChange(newValues);
    onBlur();
  };

  return (
    <Field id={id}>
      <FieldLabel>
        <label htmlFor={id} className="text-foreground font-paragraph mb-3">
          {label}
        </label>
      </FieldLabel>
      <FieldInputWrapper>
        <FieldInput>
          <div className="flex flex-wrap gap-2" role="group">
            {options.map((option) => {
              const isSelected = currentValues.includes(option.value);
              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => handleTagToggle(option.value)}
                  onFocus={onFocus}
                  aria-pressed={isSelected}
                  className={`px-4 py-2 rounded-full font-paragraph transition-all ${
                    isSelected
                      ? "bg-primary text-primary-foreground"
                      : "bg-background text-foreground border border-foreground/20 hover:border-primary/50"
                  }`}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </FieldInput>
        <FieldError className="text-destructive text-sm font-paragraph">
          {errorMessage}
        </FieldError>
      </FieldInputWrapper>
    </Field>
  );
};

export default Tags;
